﻿namespace ResultWindowsForms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.id = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.address = new System.Windows.Forms.Label();
            this.txtClass = new System.Windows.Forms.TextBox();
            this.clas = new System.Windows.Forms.Label();
            this.stream = new System.Windows.Forms.Label();
            this.sem = new System.Windows.Forms.Label();
            this.city = new System.Windows.Forms.Label();
            this.txtId = new System.Windows.Forms.NumericUpDown();
            this.txtSem = new System.Windows.Forms.NumericUpDown();
            this.txtCity = new System.Windows.Forms.ComboBox();
            this.txtStream = new System.Windows.Forms.ComboBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.txtId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSem)).BeginInit();
            this.SuspendLayout();
            // 
            // id
            // 
            this.id.AutoSize = true;
            this.id.Location = new System.Drawing.Point(28, 30);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(44, 20);
            this.id.TabIndex = 0;
            this.id.Text = "I\'d : ";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(129, 59);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(163, 26);
            this.txtName.TabIndex = 2;
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Location = new System.Drawing.Point(28, 65);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(70, 20);
            this.name.TabIndex = 2;
            this.name.Text = "Name : ";
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(129, 96);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(163, 63);
            this.txtAddress.TabIndex = 3;
            // 
            // address
            // 
            this.address.AutoSize = true;
            this.address.Location = new System.Drawing.Point(28, 102);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(90, 20);
            this.address.TabIndex = 4;
            this.address.Text = "Address : ";
            // 
            // txtClass
            // 
            this.txtClass.Location = new System.Drawing.Point(129, 171);
            this.txtClass.Name = "txtClass";
            this.txtClass.Size = new System.Drawing.Size(163, 26);
            this.txtClass.TabIndex = 4;
            // 
            // clas
            // 
            this.clas.AutoSize = true;
            this.clas.Location = new System.Drawing.Point(28, 177);
            this.clas.Name = "clas";
            this.clas.Size = new System.Drawing.Size(68, 20);
            this.clas.TabIndex = 6;
            this.clas.Text = "Class : ";
            // 
            // stream
            // 
            this.stream.AutoSize = true;
            this.stream.Location = new System.Drawing.Point(28, 215);
            this.stream.Name = "stream";
            this.stream.Size = new System.Drawing.Size(82, 20);
            this.stream.TabIndex = 8;
            this.stream.Text = "Stream : ";
            // 
            // sem
            // 
            this.sem.AutoSize = true;
            this.sem.Location = new System.Drawing.Point(28, 247);
            this.sem.Name = "sem";
            this.sem.Size = new System.Drawing.Size(60, 20);
            this.sem.TabIndex = 10;
            this.sem.Text = "Sem : ";
            // 
            // city
            // 
            this.city.AutoSize = true;
            this.city.Location = new System.Drawing.Point(28, 288);
            this.city.Name = "city";
            this.city.Size = new System.Drawing.Size(54, 20);
            this.city.TabIndex = 12;
            this.city.Text = "City : ";
            // 
            // txtId
            // 
            this.txtId.Enabled = false;
            this.txtId.Location = new System.Drawing.Point(129, 24);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(163, 26);
            this.txtId.TabIndex = 1;
            // 
            // txtSem
            // 
            this.txtSem.Location = new System.Drawing.Point(129, 245);
            this.txtSem.Name = "txtSem";
            this.txtSem.Size = new System.Drawing.Size(163, 26);
            this.txtSem.TabIndex = 6;
            // 
            // txtCity
            // 
            this.txtCity.FormattingEnabled = true;
            this.txtCity.Items.AddRange(new object[] {
            "Rajkot",
            "Jetpur",
            "Surat"});
            this.txtCity.Location = new System.Drawing.Point(129, 280);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(163, 28);
            this.txtCity.TabIndex = 7;
            // 
            // txtStream
            // 
            this.txtStream.FormattingEnabled = true;
            this.txtStream.Items.AddRange(new object[] {
            "B.Sc.It",
            "BCA"});
            this.txtStream.Location = new System.Drawing.Point(129, 207);
            this.txtStream.Name = "txtStream";
            this.txtStream.Size = new System.Drawing.Size(163, 28);
            this.txtStream.TabIndex = 5;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(23, 334);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(104, 39);
            this.btnSubmit.TabIndex = 8;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(188, 334);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(104, 39);
            this.btnClear.TabIndex = 9;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(320, 394);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.txtStream);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.txtSem);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.city);
            this.Controls.Add(this.sem);
            this.Controls.Add(this.stream);
            this.Controls.Add(this.txtClass);
            this.Controls.Add(this.clas);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.address);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.name);
            this.Controls.Add(this.id);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSem)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label id;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label address;
        private System.Windows.Forms.TextBox txtClass;
        private System.Windows.Forms.Label clas;
        private System.Windows.Forms.Label stream;
        private System.Windows.Forms.Label sem;
        private System.Windows.Forms.Label city;
        private System.Windows.Forms.NumericUpDown txtId;
        private System.Windows.Forms.NumericUpDown txtSem;
        private System.Windows.Forms.ComboBox txtCity;
        private System.Windows.Forms.ComboBox txtStream;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnClear;
    }
}

