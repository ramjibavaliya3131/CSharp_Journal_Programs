﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

/*
    WAP to perform insert, update, delete, select (crude op) and following tebles
	t1 -> student -> id, name, addres, class, streem, sem and city
	t2 -> result -> id, student id, sub1, sub2, sub3, sub4, total, persontage, result and gread 
*/
namespace ResultWindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            String ins = "insert into student values('" + txtName.Text + "','" + txtAddress.Text + "','" + txtClass.Text + "','" + txtStream.Text + "','" + txtSem.Text + "','" + txtCity.Text + "')";
            SqlDataAdapter sda = new SqlDataAdapter(ins, Class1.cn);
            int a = sda.Fill(Class1.dt);
            if (a <= 1)
            {
                MessageBox.Show("Successfuly Inserted...^_^");
                clear();
                Form2 f2 = new Form2();
                f2.Show();
                this.Hide();

            }
            else 
            {
                MessageBox.Show("Not Inserted...^_^");
            }
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            clear();   
        }


        //own private functions here
        private void clear() 
        {
            txtId.Text = "";
            txtName.Text = "";
            txtAddress.Text = "";
            txtClass.Text = "";
            txtStream.Text = "";
            txtSem.Text = "";
            txtCity.Text = "";
            txtId.Focus();
        }

      
    }
}
