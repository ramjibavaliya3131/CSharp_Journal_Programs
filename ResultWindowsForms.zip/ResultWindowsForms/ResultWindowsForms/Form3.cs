﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace ResultWindowsForms
{
    public partial class Form3 : Form
    {
        int m1, m2, m3, m4, total, per;
        String result, gread;
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
        private void calculation() 
        {
            m1 = Convert.ToInt32(txtJava.Text);
            m2 = Convert.ToInt32(txtCsharp.Text);
            m3 = Convert.ToInt32(txtOs.Text);
            m4 = Convert.ToInt32(txtNet.Text);
            total = m1 + m2 + m3 + m4;
            per = total / 4;
            if (per <= 100 || per > 80) 
            {
                result = "Pass";
                gread = "A";
            }
            else if (per <= 80 || per > 60) 
            {
                result = "Pass";
                gread = "B";
            }
            else if (per <= 60 || per > 40)
            {
                result = "Pass";
                gread = "C";
            }
            else
            {
                result = "Fail";
                gread = "-";
            }

        }
        private void btnResult_Click(object sender, EventArgs e)
        {
            calculation();
            String ins = "insert into result values('" + Convert.ToInt32(txtJava.Text) + "','" + Convert.ToInt32(txtCsharp.Text) + "','" + Convert.ToInt32(txtOs.Text) + "','" + Convert.ToInt32(txtNet.Text) + "','" + total + "','" + per + "','" + result + "','" + gread + "')";
            SqlDataAdapter sda = new SqlDataAdapter(ins, Class1.cn);

            int a = sda.Fill(Class1.dt);
            if (a <= 1)
            {
                MessageBox.Show("Result Created Successfuly...^_^");
                clear();
                Form4 f4 = new Form4();
                f4.Show();
                this.Hide();
            }
        }


        //own private functions here
        private void clear()
        {
            txtJava.Text = "";
            txtCsharp.Text = "";
            txtOs.Text = "";
            txtNet.Text = "";
        }
    }
}
